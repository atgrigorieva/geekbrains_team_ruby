import React from 'react'

export default () => {
  return <h1>Main page</h1>
}