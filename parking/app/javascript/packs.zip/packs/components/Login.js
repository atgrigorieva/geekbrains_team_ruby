import React from 'react'

export default () => {
  return <h1>Login page, hello!</h1>
}