import React, { Component } from 'react';

import { URL_CAR_CHECK } from '../../const';
import CheckCar from '../CheckCar';
import { fetchJsonURL } from '../../utils';

export default class CheckCarContainer extends Component {
  state = {
    isLoading: false,
  };

  checkCar = carNumber => {
    this.setState(state => {
      return {
        isLoading: true,
      };
    });

    fetchJsonURL(URL_CAR_CHECK, 'PATCH', {
      //actiont true - въезд, false - выезд
      action: this.props.action,
      car_number: { number: carNumber },
    })
      .then(data => data.json())
      .then(data => {
        this.setState(state => {
          return {
            isLoading: false,
          };
        });
        this.props.checkCar(data, carNumber);
      })
      .catch(error => {
        this.setState(state => {
          return {
            isLoading: false,
          };
        });
        this.props.checkCar({}, '', error);
      });
  };

  render() {
    const { isLoading } = this.state;

    if (isLoading) return <h3>Данные загружаются...</h3>;

    return <CheckCar handleSubmit={this.checkCar} />;
  }
}
