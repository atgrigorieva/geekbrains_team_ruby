import React, { Component } from 'react';
import { Link, history } from 'react-router-dom';

import GetPlace from '../GetPlace';
import CheckCarContainer from '../CheckCarContainer';
import { TYPES_OF_PARKING } from '../../const';

export default class ParkCarConteiner extends Component {
  state = {
    isCarChecked: false,
    isFound: false,
    isReserved: false,
    carNumber: '',
    driver: '',
    parkingPlace: '',
    credit: 0,
    error: '',
  };

  checkCar = (
    { found = false, reserved = false, car_info = {} },
    carNumber = '',
    error = ''
  ) => {
    const { driver_name = '', parking_place = '', credit = 0 } = car_info;
    this.setState({
      isCarChecked: true,
      isFound: found,
      isReserved: reserved,
      carNumber: carNumber,
      driver: driver_name,
      parkingPlace: parking_place,
      credit: credit,
      error: error,
    });
  };

  finishParking = (parking_place, error = '') => {
    if (error) {
      this.setState({
        error: error,
      });
    } else {
      window.alert('Забронировано место - ' + parking_place);
      this.props.history.push('/');
    }
  };

  render() {
    const {
      isCarChecked,
      isFound,
      isReserved,
      carNumber,
      driver,
      parkingPlace,
      credit,
      error,
    } = this.state;

    if (error) {
      return (
        <div>
          <h3>Ошибка!</h3>
        </div>
      );
    }

    if (!isCarChecked) {
      return <CheckCarContainer checkCar={this.checkCar} action={true} />;
    }

    if (!isReserved) {
      return isFound ? (
        <GetPlace finishParking={this.finishParking} />
      ) : (
        <GetPlace
          car={carNumber}
          driver={driver}
          types={TYPES_OF_PARKING}
          finishParking={this.finishParking}
        />
      );
    }

    return (
      <div>
        Забронировано место {parkingPlace} <br />
        {credit < 0 ? `Имеется задолженность : ${credit}` : null}
        <Link to="/" className="btn btn-primary">
          На главную
        </Link>
      </div>
    );
  }
}
