import React from 'react';
import { render } from 'react-dom';

import Owner from './components/Owner';

render(<Owner />, document.getElementById('application'));
