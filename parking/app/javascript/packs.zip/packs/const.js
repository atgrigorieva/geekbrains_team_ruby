export const URL_CAR_CHECK = 'ride_on_car_parking';

export const URL_GET_PLACE = 'get_free_place';

export const URL_CREATE_RESERVE = '/reservation_create';

export const URL_CAR_CREATE = '/car_create';

export const TYPES_OF_PARKING = ['ПОЧАСОВАЯ', 'ДНЕВНАЯ', 'МЕСЯЧНАЯ', 'ГОДОВАЯ'];
